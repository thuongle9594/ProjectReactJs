package com.thuong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnPhysicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
