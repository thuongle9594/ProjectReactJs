package com.thuong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnPhysicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnPhysicsApplication.class, args);
	}

}
